import streamlit as st
from mycomponent import mycomponent
core_msg = {"core_message": "test message"}
value = mycomponent(my_input_value=core_msg)
st.write("Received", value)