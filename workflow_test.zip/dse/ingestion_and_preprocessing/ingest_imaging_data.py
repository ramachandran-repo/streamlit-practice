import boto3
import zipfile
import os
import cv2
import numpy as np

def load_images_from_directory(directory):
    images = []
    filenames = []
    for filename in os.listdir(directory):
        if filename.endswith(('.png', '.jpg', '.jpeg')):
            img_path = os.path.join(directory, filename)
            try:
                img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
                if img is not None:
                    images.append(img)
                    filenames.append(filename)
                else:
                    print(f"Warning: Failed to read {filename}")
            except Exception as e:
                print(f"Error processing {filename}: {e}")
    return images, filenames

def resize_images(images, size=(224, 224)):
    resized_images = []
    for img in images:
        try:
            resized_img = cv2.resize(img, size)
            resized_images.append(resized_img)
        except Exception as e:
            print(f"Error resizing image: {e}")
    return resized_images

def normalize_images(images):
    normalized_images = []
    for img in images:
        try:
            normalized_img = img / 255.0
            normalized_images.append(normalized_img)
        except Exception as e:
            print(f"Error normalizing image: {e}")
    return normalized_images

def save_preprocessed_images(images, filenames, output_directory):
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)
    
    for img, filename in zip(images, filenames):
        try:
            output_path = os.path.join(output_directory, filename)
            cv2.imwrite(output_path, (img * 255).astype(np.uint8))  # Convert back to 8-bit before saving
        except Exception as e:
            print(f"Error saving {filename}: {e}")

def preprocess_images(input_directory, output_directory):
    images, filenames = load_images_from_directory(input_directory)
    resized_images = resize_images(images)
    normalized_images = normalize_images(resized_images)
    save_preprocessed_images(normalized_images, filenames, output_directory)
    print("Preprocessing completed.")

def ingest_imaging_data():
    s3 = boto3.client('s3')
    bucket_name = 'common_test_bucket2024'
    imaging_key = 'imaging/input/imaging_data.zip'
    
    s3.download_file(bucket_name, imaging_key, '/tmp/imaging_data.zip')
    
    with zipfile.ZipFile('/tmp/imaging_data.zip', 'r') as zip_ref:
        zip_ref.extractall('/tmp/imaging_data')
    
    output_directory = '/tmp/preprocessed_imaging_data'
    preprocess_images('/tmp/imaging_data', output_directory)
    
    with zipfile.ZipFile('/tmp/processed_imaging_data.zip', 'w') as zip_ref:
        for folder_name, subfolders, filenames in os.walk('/tmp/imaging_data'):
            for filename in filenames:
                file_path = os.path.join(folder_name, filename)
                zip_ref.write(file_path, os.path.relpath(file_path, '/tmp/imaging_data'))
    
    # Save the processed data to a new S3 location
    processed_key = 'imaging/processed/imaging_data.zip'
    s3.upload_file('/tmp/processed_imaging_data.zip', bucket_name, processed_key)

if __name__ == "__main__":
    ingest_imaging_data()
