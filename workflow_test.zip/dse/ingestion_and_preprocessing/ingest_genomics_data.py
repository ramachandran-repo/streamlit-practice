import boto3
import pandas as pd

def ingest_genomics_data():
    s3 = boto3.client('s3')
    bucket_name = 'common_test_bucket2024'
    genomics_key = 'genomics/input/genomics_data.csv'
    
    s3.download_file(bucket_name, genomics_key, '/tmp/genomics_data.csv')
    
    df = pd.read_csv('/tmp/genomics_data.csv')
    
    df.dropna(inplace=True)  # Remove rows with null values
    df.fillna(df.mean(), inplace=True)  # Impute missing data with column mean
    
    processed_key = 'genomics/processed/genomics_data.csv'
    df.to_csv('/tmp/processed_genomics_data.csv', index=False)
    s3.upload_file('/tmp/processed_genomics_data.csv', bucket_name, processed_key)

if __name__ == "__main__":
    ingest_genomics_data()
