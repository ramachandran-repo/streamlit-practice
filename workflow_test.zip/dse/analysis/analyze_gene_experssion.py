import boto3
import pandas as pd
from scipy.stats import ttest_ind

def analyze_gene_expression():
    s3 = boto3.client('s3')
    bucket_name = 'common_test_bucket2024'
    processed_key = 'genomics/processed/genomics_data.csv'
    
    s3.download_file(bucket_name, processed_key, '/tmp/processed_genomics_data.csv')
    
    df = pd.read_csv('/tmp/processed_genomics_data.csv')
    
    group1 = df[df['group'] == 'group1']
    group2 = df[df['group'] == 'group2']
    
    results = []
    for gene in df.columns[1:]:
        t_stat, p_value = ttest_ind(group1[gene], group2[gene])
        results.append({'gene': gene, 't_stat': t_stat, 'p_value': p_value})
    
    results_df = pd.DataFrame(results)
    
    results_key = 'genomics/analysis/results/gene_expression_analysis.csv'
    results_df.to_csv('/tmp/gene_expression_analysis.csv', index=False)
    s3.upload_file('/tmp/gene_expression_analysis.csv', bucket_name, results_key)

if __name__ == "__main__":
    analyze_gene_expression()
