import boto3
import pandas as pd

def analyze_pro():
    s3 = boto3.client('s3')
    bucket_name = 'common_test_bucket2024'
    processed_key = 'pro/processed/pro_data.csv'
    
    s3.download_file(bucket_name, processed_key, '/tmp/processed_pro_data.csv')
    
    df = pd.read_csv('/tmp/processed_pro_data.csv')
    
    df['change_score'] = df['post_treatment'] - df['pre_treatment']
    
    results_key = 'pro/analysis/results/pro_analysis.csv'
    df.to_csv('/tmp/pro_analysis.csv', index=False)
    s3.upload_file('/tmp/pro_analysis.csv', bucket_name, results_key)

if __name__ == "__main__":
    analyze_pro()
