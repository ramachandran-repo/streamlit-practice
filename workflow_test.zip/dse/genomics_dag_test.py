from airflow import DAG
from airflow.providers.amazon.aws.operators.ecs import ECSOperator
from airflow.utils.dates import days_ago
from datetime import timedelta

# Define default arguments
default_args = {
    'owner': 'airflow',
    'start_date': days_ago(1),
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

# Define the DAG
dag = DAG(
    'cancer_treatment_analysis',
    default_args=default_args,
    description='DAG for cancer treatment analysis using ECS tasks',
    schedule_interval=None,
)

# Define ECS task configurations
ecs_task_config = {
    'launchType': 'EC2',  # or 'FARGATE'
    'cluster': 'test-dse-cluster',
    'networkConfiguration': {
        'awsvpcConfiguration': {
            'subnets': ['subnet-048838bf713f76aa8'],
            'assignPublicIp': 'ENABLED',
        },
    },
}

# Define ECS tasks
ingest_genomics_data = ECSOperator(
    task_id='ingest_genomics_data',
    task_definition='genomics-ingestion',
    overrides={
        'containerOverrides': [
            {
                'name': 'dse_docker_automation_test',
                'image': '266994203134.dkr.ecr.eu-central-1.amazonaws.com/dse_test:docker_automation_test',
                'command': ['ingestion_and_preprocessing/ingest_genomics_data.py'],
            },
        ],
    },
    **ecs_task_config,
    dag=dag,
)

ingest_imaging_data = ECSOperator(
    task_id='ingest_imaging_data',
    task_definition='imaging-ingestion',
    overrides={
        'containerOverrides': [
            {
                'name': 'dse_docker_automation_test',
                'image': '266994203134.dkr.ecr.eu-central-1.amazonaws.com/dse_test:docker_automation_test',
                'command': ['ingestion_and_preprocessing/ingest_imaging.py'],
            },
        ],
    },
    **ecs_task_config,
    dag=dag,
)

ingest_pro_data = ECSOperator(
    task_id='ingest_pro_data',
    task_definition='pro-ingestion',
    overrides={
        'containerOverrides': [
            {
                'name': 'dse_docker_automation_test',
                'image': '266994203134.dkr.ecr.eu-central-1.amazonaws.com/dse_test:docker_automation_test',
                'command': ['ingestion_and_preprocessing/ingest_pro.py'],
            },
        ],
    },
    **ecs_task_config,
    dag=dag,
)

analyze_gene_expression = ECSOperator(
    task_id='analyze_gene_expression',
    task_definition='gene-expression-analysis',
    overrides={
        'containerOverrides': [
            {
                'name': 'dse_docker_automation_test',
                'image': '266994203134.dkr.ecr.eu-central-1.amazonaws.com/dse_test:docker_automation_test',
                'command': ['analysis/analyze_gene_expression.py'],
            },
        ],
    },
    **ecs_task_config,
    dag=dag,
)

analyze_imaging = ECSOperator(
    task_id='analyze_imaging',
    task_definition='imaging-analysis',
    overrides={
        'containerOverrides': [
            {
                'name': 'dse_docker_automation_test',
                'image': '266994203134.dkr.ecr.eu-central-1.amazonaws.com/dse_test:docker_automation_test',
                'command': ['analysis/analyze_imaging.py'],
            },
        ],
    },
    **ecs_task_config,
    dag=dag,
)

analyze_pro = ECSOperator(
    task_id='analyze_pro',
    task_definition='pro-analysis',
    overrides={
        'containerOverrides': [
            {
                'name': 'dse_docker_automation_test',
                'image': '266994203134.dkr.ecr.eu-central-1.amazonaws.com/dse_test:docker_automation_test',
                'command': ['analysis/analyze_pro.py'],
            },
        ],
    },
    **ecs_task_config,
    dag=dag,
)

classify_response = ECSOperator(
    task_id='classify_response',
    task_definition='classify-resulta',
    overrides={
        'containerOverrides': [
            {
                'name': 'dse_docker_automation_test',
                'image': '266994203134.dkr.ecr.eu-central-1.amazonaws.com/dse_test:docker_automation_test',
                'command': ['classify_response.py'],
            },
        ],
    },
    **ecs_task_config,
    dag=dag,
)

identify_biomarkers = ECSOperator(
    task_id='identify_biomarkers',
    task_definition='biomarker-identification',
    overrides={
        'containerOverrides': [
            {
                'name': 'dse_docker_automation_test',
                'image': '266994203134.dkr.ecr.eu-central-1.amazonaws.com/dse_test:docker_automation_test',
                'command': ['identify_biomarkers.py'],
            },
        ],
    },
    **ecs_task_config,
    dag=dag,
)

generate_reports = ECSOperator(
    task_id='generate_reports',
    task_definition='report-generation',
    overrides={
        'containerOverrides': [
            {
                'name': 'dse_docker_automation_test',
                'image': '266994203134.dkr.ecr.eu-central-1.amazonaws.com/dse_test:docker_automation_test',
                'command': ['generate_reports.py'],
            },
        ],
    },
    **ecs_task_config,
    dag=dag,
)

# Set task dependencies
[ingest_genomics_data, ingest_imaging_data, ingest_pro_data] >> analyze_gene_expression
[ingest_genomics_data, ingest_imaging_data, ingest_pro_data] >> analyze_imaging
[ingest_genomics_data, ingest_imaging_data, ingest_pro_data] >> analyze_pro

analyze_gene_expression >> classify_response
analyze_imaging >> classify_response
analyze_pro >> classify_response

classify_response >> identify_biomarkers
classify_response >> generate_reports
identify_biomarkers >> generate_reports
