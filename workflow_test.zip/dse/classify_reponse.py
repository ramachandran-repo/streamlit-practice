import boto3
import pandas as pd

def classify_response():
    s3 = boto3.client('s3')
    bucket_name = 'common_test_bucket2024'
    
    # Download analysis results
    s3.download_file(bucket_name, 'genomics/analysis/results/gene_expression_analysis.csv', '/tmp/gene_expression_analysis.csv')
    s3.download_file(bucket_name, 'imaging/analysis/results/imaging_analysis.csv', '/tmp/imaging_analysis.csv')
    s3.download_file(bucket_name, 'pro/analysis/results/pro_analysis.csv', '/tmp/pro_analysis.csv')
    
    # Read the data into DataFrames
    gene_df = pd.read_csv('/tmp/gene_expression_analysis.csv')
    imaging_df = pd.read_csv('/tmp/imaging_analysis.csv')
    pro_df = pd.read_csv('/tmp/pro_analysis.csv')
    
    # Simple rule-based classification
    classifications = []
    for index, row in gene_df.iterrows():
        if row['p_value'] < 0.05:
            classifications.append('responder')
        else:
            classifications.append('non-responder')
    
    # Save the classification results
    classification_df = pd.DataFrame({'patient_id': gene_df['gene'], 'classification': classifications})
    classification_df.to_csv('/tmp/classification_results.csv', index=False)
    s3.upload_file('/tmp/classification_results.csv', bucket_name, 'classification/results/classification_results.csv')

if __name__ == "__main__":
    classify_response()
